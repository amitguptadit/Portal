package com.emp.controller;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.emp.exceptionhandling.ResourceNotFoundException;
import com.emp.model.Employee;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceException;

@RestController
public class EmployeeDetailsController {

	@Inject
	@Qualifier("employeeService")
	EmployeeService employeeService;

	@RequestMapping(value = "/employee1", method = RequestMethod.GET)
	public Employee getEmployeeDetails() throws ResourceNotFoundException, EmployeeServiceException {

		Employee employee1 = employeeService.getEmployee();

		if (employee1 == null) {
			throw new ResourceNotFoundException("Employee1 not found");
		}
		return employee1;
	}

	@RequestMapping(value = "/employee2", method = RequestMethod.GET)
	public Employee getEmployeeInformation() throws ResourceNotFoundException, EmployeeServiceException {

		Employee employee2 = employeeService.getEmployeeNull();
		if (employee2 == null) {
			throw new ResourceNotFoundException("Employee2 not found");
		}

		return employee2;
	}

	@RequestMapping(value = "/employee3", method = RequestMethod.GET)
	public Employee getEmployeeData() throws ResourceNotFoundException, EmployeeServiceException {
		try {
			Employee employee3 = employeeService.getEmployeeException();
			if (employee3 == null) {
				throw new ResourceNotFoundException("Employee3 not found");
			}
			return employee3;
		} catch (EmployeeServiceException e) {
			throw new EmployeeServiceException("Internal Server Exception while getting exception");
		}
	}
}
