package com.emp.service;

import org.springframework.stereotype.Service;

import com.emp.model.Employee;

@Service
public class EmployeeService {

	public Employee getEmployee() throws EmployeeServiceException {
		Employee emp = new Employee();
		emp.setName("AMIT GUPTA");
		emp.setDesignation("developer");
		emp.setEmpId(67986);
		emp.setSalary(35000);

		return emp;
	}

	public Employee getEmployeeNull() throws EmployeeServiceException {

		return null;
	}

	public Employee getEmployeeException() throws EmployeeServiceException {

		throw new EmployeeServiceException();
	}

}
