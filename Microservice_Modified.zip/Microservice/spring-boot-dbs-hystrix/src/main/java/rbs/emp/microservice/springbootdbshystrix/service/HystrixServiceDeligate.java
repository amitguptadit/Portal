package rbs.emp.microservice.springbootdbshystrix.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
	public class HystrixServiceDeligate {
	 
	    @Autowired
	    RestTemplate restTemplate;
	     
	    @HystrixCommand(fallbackMethod = "callStudentServiceAndGetData_Fallbackaaa")
	    public String callHystrixServiceAndGetData(String projectName) {
	 
	        System.out.println("Getting School details for " + projectName);
	 
	        String response = restTemplate
	                .exchange("http://localhost:1111/getEmployeeDetailFromProject/{projectName}"
	                , HttpMethod.GET
	                , null
	                , new ParameterizedTypeReference<String>() {
	            }, projectName).getBody();
	 
	        System.out.println("Response Received as " + response + " -  " + new Date());
	 
	        return "NORMAL FLOW !!! - project name -  " + projectName + " :::  " +
	                    " Student Details " + response + " -  " + new Date();
	    }
	     
	    @SuppressWarnings("unused")
	    private String callStudentServiceAndGetData_Fallback(String schoolname) {
	 
	        System.out.println("project  Service is down!!! fallback route enabled...");
	 
	        return "CIRCUIT BREAKER ENABLED!!! No Response From project Service at this moment. " +
	                    " Service will be back shortly - " + new Date();
	    }
	 
	    @SuppressWarnings("unused")
		private int callStudentServiceAndGetData_Fallbackaaa(String schoolname) {
	   	 
	        System.out.println("abc");
	 
	        return 0;
	    }
	 
	    @Bean
	    public RestTemplate restTemplate() {
	        return new RestTemplate();
	    }
	}

