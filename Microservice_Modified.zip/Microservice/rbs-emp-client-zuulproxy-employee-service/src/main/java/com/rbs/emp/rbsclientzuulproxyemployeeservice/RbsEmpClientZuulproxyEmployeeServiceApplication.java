package com.rbs.emp.rbsclientzuulproxyemployeeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class RbsEmpClientZuulproxyEmployeeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RbsEmpClientZuulproxyEmployeeServiceApplication.class, args);
	}
}
