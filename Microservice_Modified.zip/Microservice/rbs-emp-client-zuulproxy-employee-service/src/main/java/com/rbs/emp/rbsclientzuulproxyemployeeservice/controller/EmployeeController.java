package com.rbs.emp.rbsclientzuulproxyemployeeservice.controller;

import java.util.Date;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbs.emp.rbsclientzuulproxyemployeeservice.model.Employee;

@RestController
public class EmployeeController {
	
@RequestMapping( value="/getEmployeeData/{name}")
public String getEmployeeData(@PathVariable (name= "name") String name)
{
	return "Hi  my name is " + name + ":::::::::::::::::::::::" +"     time in response is "+ new Date();
	
}

	

@RequestMapping( value="/getEmployee/{name}")
public Employee getEmployee(@PathVariable (name= "name") String name)
{
	
	return new Employee(name,"101","delhi");
	
	
}
	
}
