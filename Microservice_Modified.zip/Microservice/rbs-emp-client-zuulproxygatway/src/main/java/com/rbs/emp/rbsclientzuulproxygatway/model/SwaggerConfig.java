package com.rbs.emp.rbsclientzuulproxygatway.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.common.collect.ImmutableList;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket postsApi() {
		
		Docket docket=new Docket(DocumentationType.SWAGGER_2);
			
			 /*docket.groupName("public-api")
					.apiInfo(apiInfo()).select().paths(postPaths()).build();*/
			 docket.globalResponseMessage(RequestMethod.GET, ImmutableList.of(new ResponseMessageBuilder()
	         .code(650)
	         .message("Bad Request hi")
	         .code(200)
	         .message("successfull message")
	         .responseModel(new ModelRef("Error")).build(),new ResponseMessageBuilder()
	         .code(500)
	         .message("Internal Server Error when response code is")
	         .responseModel(new ModelRef("Error")).build()));
	         
	          return docket;
	}
	
	/*private Predicate<String> postPaths() {
		return or(regex("/api/posts.*"), regex("/dbs.*"));
	}*/


	private ApiInfo apiInfo() {
		return new ApiInfoBuilder().title("API")
				.description("API  for swagger information")
				.termsOfServiceUrl("http://localhost")
				.contact("amit.guptadit@gmail.com").license("GMAIL")
				.licenseUrl("https://www.gmail.com").version("1.0").build();
	}

	
}