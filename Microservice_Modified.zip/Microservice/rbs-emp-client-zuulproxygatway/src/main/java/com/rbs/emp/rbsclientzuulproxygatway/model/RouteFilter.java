package com.rbs.emp.rbsclientzuulproxygatway.model;

import com.netflix.zuul.ZuulFilter;

public class RouteFilter extends ZuulFilter {

	
	@Override
	public Object run() {
		System.out.println("inside route filter");
		return null;
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public int filterOrder() {
		return 1;
	}

	@Override
	public String filterType() {
		
		return "route";
	}
}
