package springcloudproducer.producerservice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProducerController {
	
	
	@RequestMapping(value ="/producer", method = RequestMethod.GET)
	public List<Employee> EmployeeName()
	{
		Employee emp1= new Employee();	
		Employee emp2= new Employee();
		Employee emp3= new Employee();	
		List<Employee> empList= new ArrayList<Employee>();
		
		emp1.setEmpId(67986);
		emp1.setDesignation("Technical Analyst");
		emp1.setName("Amit Gupta");
		emp1.setSalary(3000);
		
		
		emp2.setEmpId(47986);
		emp2.setDesignation("Technical Architect");
		emp2.setName("Yashpal Gandhi");
		emp2.setSalary(2000);
		
		emp3.setEmpId(79414);
		emp3.setDesignation("Specialist");
		emp3.setName("Vivek Srivastava");
		emp3.setSalary(4500);
		
		
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		
		return empList;
	}
	
	@RequestMapping(value ="/producer/sortedByName", method = RequestMethod.GET)
	public List<Employee> EmployeeSortByName()
	{
		Employee emp1= new Employee();	
		Employee emp2= new Employee();
		Employee emp3= new Employee();	
		List<Employee> empList= new ArrayList<Employee>();
		
		emp1.setEmpId(67986);
		emp1.setDesignation("Technical Analyst");
		emp1.setName("Amit Gupta");
		emp1.setSalary(3000);
		
		
		emp2.setEmpId(47986);
		emp2.setDesignation("Technical Architect");
		emp2.setName("Yashpal Gandhi");
		emp2.setSalary(2000);
		
		emp3.setEmpId(79414);
		emp3.setDesignation("Specialist");
		emp3.setName("Vivek Srivastava");
		emp3.setSalary(4500);
		
		
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		//Sorting by Name
		Collections.sort(empList, Employee.NameComparator);
		//list.sort(Comparator.comparing(Employee::getSalary).thenComparing(Employee::getName));
		return empList;
		
	}
	
	@RequestMapping(value ="/producer/sortedBySalary", method = RequestMethod.GET)
	public List<Employee> EmployeeSortBySalary()
	{
		Employee emp1= new Employee();	
		Employee emp2= new Employee();
		Employee emp3= new Employee();	
		List<Employee> empList= new ArrayList<Employee>();
		
		emp1.setEmpId(67986);
		emp1.setDesignation("Technical Analyst");
		emp1.setName("Amit Gupta");
		emp1.setSalary(3000);
		
		
		emp2.setEmpId(47986);
		emp2.setDesignation("Technical Architect");
		emp2.setName("Yashpal Gandhi");
		emp2.setSalary(2000);
		
		emp3.setEmpId(79414);
		emp3.setDesignation("Specialist");
		emp3.setName("Vivek Srivastava");
		emp3.setSalary(4500);
		
		
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		
		//Sorting by Salary
		Collections.sort(empList, Employee.SalaryComparator);
		return empList;
		
	}

	
	
}
