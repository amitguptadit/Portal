package springcloudproducer.producerservice;

import java.util.Comparator;

public class Employee  implements Comparable<Employee>{
	private int empId;
	private String name;
	private String designation;
	//private double salary;
	private int salary;
	
    public static final Comparator<Employee> SalaryComparator = new Comparator<Employee>(){

        @Override
        public int compare(Employee o1, Employee o2) {
            return (o1.salary - o2.salary); // salary is also positive integer
        }
       
    };
   
    public static final Comparator<Employee> NameComparator = new Comparator<Employee>(){

        @Override
        public int compare(Employee o1, Employee o2) {
            return o1.name.compareTo(o2.name);
        }
       
    };

    
	public Employee() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}



	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	@Override
	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		return this.empId - emp.empId;
	}

}
