package com.ribbonservice.riboonservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiboonserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiboonserviceApplication.class, args);
	}
}
