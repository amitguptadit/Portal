package com.ribbonservice.ribbonservice.controller;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class RibbonController {

	 private static org.slf4j.Logger log = LoggerFactory.getLogger(RibbonController.class);
	    @RequestMapping(value = "/ribbon",method = RequestMethod.GET)
	    public String ribbon() {
	        log.info("Access /ribbon");
	        List<String> greetings = Arrays.asList("Hi there", "Greetings", "Salutations");
	        Random rand = new Random();
	        int randomNum = rand.nextInt(greetings.size());
	        return greetings.get(randomNum);
	    }
	    @RequestMapping(value = "/")
	    public String home() {
	        log.info("Access /");
	        return "Hi!";
	    }
}
