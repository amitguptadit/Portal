package springcloudconsumer.consumerservice;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClientException;

@SpringBootApplication
public class ConsumerServiceApplication {

	public static void main(String[] args) throws RestClientException, IOException {
		ApplicationContext ctx = SpringApplication.run(
				ConsumerServiceApplication.class, args);
		
		ConsumerController consumerControllerClient=ctx.getBean(ConsumerController.class);
		System.out.println("bean class name"+consumerControllerClient);
		consumerControllerClient.getEmployee();
		
		consumerControllerClient.getEmployeeSortedByName();
		consumerControllerClient.getEmployeeSortedBySalary();
		
	}
	
	
}

