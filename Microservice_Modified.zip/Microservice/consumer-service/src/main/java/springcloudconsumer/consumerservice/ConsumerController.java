package springcloudconsumer.consumerservice;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
@RestController
public class ConsumerController {
	/*
	 * @Autowired private DiscoveryClient discoveryClient;
	 * 
	 * public void getEmployee() throws RestClientException, IOException {
	 * 
	 * List<ServiceInstance>
	 * instances=discoveryClient.getInstances("producer-service"); ServiceInstance
	 * serviceInstance=instances.get(0);
	 * 
	 * String baseUrl=serviceInstance.getUri().toString();
	 * 
	 * baseUrl=baseUrl+"/producer";
	 * 
	 * RestTemplate restTemplate = new RestTemplate(); ResponseEntity<String>
	 * response=null; try{ response=restTemplate.exchange(baseUrl, HttpMethod.GET,
	 * getHeaders(),String.class); }catch (Exception ex) { System.out.println(ex); }
	 * System.out.println(response.getBody()); }
	 * 
	 * private static HttpEntity<?> getHeaders() throws IOException { HttpHeaders
	 * headers = new HttpHeaders(); headers.set("Accept",
	 * MediaType.APPLICATION_JSON_VALUE); return new HttpEntity<>(headers); }
	 */

	@Autowired
	private LoadBalancerClient LoadBalancer;
	public void getEmployee() throws RestClientException, IOException {
		ServiceInstance serviceInstance = LoadBalancer.choose("producer-service");
		System.out.println(serviceInstance.getUri());
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/producer";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		try {
			response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		System.out.println(response.getBody());
	}
	
	public void getEmployeeSortedByName() throws RestClientException, IOException {
		ServiceInstance serviceInstance = LoadBalancer.choose("producer-service");
		System.out.println(serviceInstance.getUri());
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/producer/sortedByName";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		try {
			response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		System.out.println("Employee SortedByName --> "+response.getBody());
	}
	
	public void getEmployeeSortedBySalary() throws RestClientException, IOException {
		ServiceInstance serviceInstance = LoadBalancer.choose("producer-service");
		System.out.println(serviceInstance.getUri());
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl + "/producer/sortedBySalary";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		try {
			response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		System.out.println("Employee SortedBySalary --> "+response.getBody());
	}

	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	
}
	
}
